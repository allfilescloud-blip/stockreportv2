import { useState, useEffect } from 'react';
import { MapPin, Plus, Edit2, Trash2, X, Check, Loader2 } from 'lucide-react';
import { collection, query, onSnapshot, doc, updateDoc, setDoc, deleteDoc } from 'firebase/firestore';
import { db } from '../../db/firebase';

interface Location {
    id: string;
    name: string;
    createdAt?: any;
}

export const LocationSettings = () => {
    const [locations, setLocations] = useState<Location[]>([]);
    const [showLocationModal, setShowLocationModal] = useState(false);
    const [editingLocation, setEditingLocation] = useState<Location | null>(null);
    const [locationName, setLocationName] = useState('');
    const [isSavingLocation, setIsSavingLocation] = useState(false);

    useEffect(() => {
        const qLocations = query(collection(db, 'locations'));
        const unsubscribeLocations = onSnapshot(qLocations, (snapshot) => {
            const locs = snapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data()
            })) as Location[];
            locs.sort((a, b) => a.name.localeCompare(b.name));
            setLocations(locs);
        });

        return () => {
            unsubscribeLocations();
        };
    }, []);

    const handleSaveLocation = async () => {
        if (!locationName.trim()) return;
        setIsSavingLocation(true);
        try {
            if (editingLocation) {
                await updateDoc(doc(db, 'locations', editingLocation.id), {
                    name: locationName.trim()
                });
            } else {
                await setDoc(doc(collection(db, 'locations')), {
                    name: locationName.trim(),
                    createdAt: new Date()
                });
            }
            setShowLocationModal(false);
            setEditingLocation(null);
            setLocationName('');
        } catch (error) {
            console.error('Erro ao salvar local:', error);
            alert('Erro ao salvar o local. Tente novamente.');
        } finally {
            setIsSavingLocation(false);
        }
    };

    const handleDeleteLocation = async (id: string) => {
        if (window.confirm('Tem certeza que deseja excluir este local?')) {
            try {
                await deleteDoc(doc(db, 'locations', id));
            } catch (error) {
                console.error('Erro ao deletar local:', error);
            }
        }
    };

    return (
        <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-xl">
                <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                    <h3 className="text-slate-900 dark:text-white font-bold text-lg flex items-center gap-2">
                        <MapPin size={24} className="text-blue-500" />
                        Locais de Estoque
                    </h3>
                    <button
                        onClick={() => {
                            setEditingLocation(null);
                            setLocationName('');
                            setShowLocationModal(true);
                        }}
                        className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 transition-all shadow-md active:scale-95"
                    >
                        <Plus size={18} /> Novo Local
                    </button>
                </div>
                <div className="divide-y divide-slate-100 dark:divide-slate-800/60 p-2">
                    {locations.length === 0 ? (
                        <div className="p-12 text-center">
                            <div className="w-16 h-16 bg-slate-100 dark:bg-slate-800 rounded-2xl flex items-center justify-center mx-auto mb-4 text-slate-500">
                                <MapPin size={32} />
                            </div>
                            <p className="text-slate-500 font-medium">Nenhum local cadastrado.</p>
                        </div>
                    ) : (
                        locations.map((loc) => (
                            <div key={loc.id} className="p-4 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/40 rounded-2xl transition-colors group">
                                <div className="flex items-center gap-4">
                                    <div className="w-10 h-10 bg-blue-500/10 rounded-xl flex items-center justify-center text-blue-500 font-bold group-hover:scale-110 transition-transform">
                                        <MapPin size={20} />
                                    </div>
                                    <div>
                                        <p className="text-slate-900 dark:text-white font-bold">{loc.name}</p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <button
                                        onClick={() => {
                                            setEditingLocation(loc);
                                            setLocationName(loc.name);
                                            setShowLocationModal(true);
                                        }}
                                        className="p-2 text-slate-400 hover:text-blue-500 bg-white dark:bg-slate-900 hover:bg-blue-50 dark:hover:bg-blue-500/10 rounded-xl transition-all shadow-sm border border-slate-200 dark:border-slate-700"
                                        title="Editar Local"
                                    >
                                        <Edit2 size={18} />
                                    </button>
                                    <button
                                        onClick={() => handleDeleteLocation(loc.id)}
                                        className="p-2 text-slate-400 hover:text-red-500 bg-white dark:bg-slate-900 hover:bg-red-50 dark:hover:bg-red-500/10 rounded-xl transition-all shadow-sm border border-slate-200 dark:border-slate-700"
                                        title="Excluir Local"
                                    >
                                        <Trash2 size={18} />
                                    </button>
                                </div>
                            </div>
                        ))
                    )}
                </div>
            </div>

            {/* Modal de Local */}
            {showLocationModal && (
                <div className="fixed inset-0 z-[90] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
                    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-200">
                        <div className="p-6">
                            <div className="flex justify-between items-center mb-6">
                                <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                                    <MapPin className="text-blue-500" size={24} />
                                    {editingLocation ? 'Editar Local' : 'Novo Local'}
                                </h2>
                                <button onClick={() => setShowLocationModal(false)} className="text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 p-2 rounded-full transition-colors">
                                    <X size={24} />
                                </button>
                            </div>

                            <div className="space-y-4">
                                <div>
                                    <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Nome do Local</label>
                                    <input
                                        type="text"
                                        value={locationName}
                                        onChange={(e) => setLocationName(e.target.value)}
                                        className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl px-4 py-3 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                                        placeholder="Ex: Depósito Central, Prateleira A..."
                                        autoFocus
                                    />
                                </div>
                            </div>

                            <div className="mt-8">
                                <button
                                    onClick={handleSaveLocation}
                                    disabled={isSavingLocation || !locationName.trim()}
                                    className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-blue-600/20 active:scale-95"
                                >
                                    {isSavingLocation ? <Loader2 className="animate-spin" size={20} /> : <Check size={20} />}
                                    {isSavingLocation ? 'Salvando...' : 'Salvar Local'}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};
